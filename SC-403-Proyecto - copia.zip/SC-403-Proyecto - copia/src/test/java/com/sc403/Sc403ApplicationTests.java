package com.sc403;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sc403ApplicationTests {

	@Test
	void contextLoads() {
	}

}
